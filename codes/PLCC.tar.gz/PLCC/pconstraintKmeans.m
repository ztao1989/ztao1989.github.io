function [index, sumbest] = pconstraintKmeans(data, K, pIDX, lambda)
% K-means with sqEuclidean distance with partitioning-level constraint
[n,m] = size(data);
r = size(pIDX,2);
Ki = max(pIDX);
maxIter =40; 
centroid = initialCentroid(data, K, n, r, Ki);
sumbest = inf;
for i = 1 : maxIter
    D = getDistance(data, pIDX, centroid, K, n, m, r, lambda, Ki);
    [d, idx] = min(D, [], 2); 
    totalsum = sum(d);
    if abs(sumbest - totalsum) < 1e-5
        break;           
    else %if totalsum < sumbest
        index = idx; 
        centroid = getCentroid(data, pIDX, index, K, n, m, r, Ki);
        sumbest = totalsum;
    end
end
end

function centroid = initialCentroid(data, K, n, r, Ki)
    centroid = data(randsample(n,K),:);
    C = zeros(K, sum(Ki));
    for i = 1 : r
        for k = 1 : K
            if i == 1
                C(k, randsample(Ki(i),1)) =1;
            else
                C(k, randsample(Ki(i),1)+sum(Ki(1:i-1))) =1;
            end
        end
    end
    centroid = [centroid C];
end

function centroid = getCentroid(data, pIDX, index, K, n, m, r, Ki)
    centroid = zeros(K,m);
    C = zeros(K, r*K);
    for k = 1 : K
       members = (index==k);
       if any(members)
          centroid(k,:) = sum(data(members,:))/sum(members); 
          
          counts = hist(pIDX(members,:),0:max(Ki));
          if size(counts,1)==1
            counts = counts';
          end

          for i = 1 : r
              if counts(1,i) == sum(members)
                  C(k, randsample(K,1)+ (i-1)*K) =1;
              else
                if i==1
                  C(k,1:Ki(i)) = counts(2:Ki(i)+1,i)/(sum(members)- counts(1,i));
                else
                  C(k,sum(Ki(1:i-1))+1:sum(Ki(1:i))) = counts(2:Ki(i)+1,i)/(sum(members)- counts(1,i));  
                end
                  
              end
          end
          
       else
          centroid(k,:) = data(randsample(n,1),:);
          for i = 1 : r
            if i == 1
                C(k, randsample(Ki(i),1)) =1;
            else
                C(k, randsample(Ki(i),1)+sum(Ki(1:i-1))) =1;
            end
          end
       end
    end
    centroid = [centroid C];
end

function D = getDistance(data, pIDX, centroid, K, n, m, r, lambda, Ki)
    D = zeros(n, K);
    P = zeros(n, K);
    for k = 1 : K
       D(:,k) = sum((data -  centroid(repmat(k,n,1),1:m)).^2,2);
    end
    
    for i = 1 : r
       temp = pIDX(:,i);
       matrix = getBinaryMatrix(temp);
       l = temp >0;
       count = sum(l);
       for k = 1 : K
          if i ==1
            P(l,k) =  lambda * sum((matrix(l,:) -  centroid(repmat(k,count,1),m+1:m+Ki(i))).^2,2);
          else
            P(l,k) =  lambda * sum((matrix(l,:) -  centroid(repmat(k,count,1),m+sum(Ki(1:i-1))+1:m+sum(Ki(1:i)))).^2,2);  
          end
       end
       D = D + P;
    end
end