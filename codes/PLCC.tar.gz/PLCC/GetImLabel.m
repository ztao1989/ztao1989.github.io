function imglabel = GetImLabel(labels,ind)
    num = length(labels);
    if nargin<2,
        ind = zeros(1,num);
        ind(1) = 1;
    end
    [r,c] = size(labels{1});
    imglabel = zeros(r*c*num,1);
    for i=1:num,
        label = reshape(labels{i},[r*c 1]);
        imglabel((i-1)*r*c+1:i*r*c,1) = ind(i)*label;
    end;
    imglabel = imglabel + 1;
end

