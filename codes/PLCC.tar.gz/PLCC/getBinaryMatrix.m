function result = getBinaryMatrix(IDX)
    [n,r] = size(IDX);
    Ki = max(IDX);
    result = zeros(n, sum(Ki));
    for i = 1 : r
        temp = IDX(:,r);
        l = temp>0;
        label =eye(Ki(i));
        if i==1
            result(l,1 : Ki(1)) = label(IDX(l,r),:);
        else
            result(l,sum(Ki(1:i-1)) + 1 : sum(Ki(1:i))) = label(IDX(l,r),:);
        end
    end
end


    