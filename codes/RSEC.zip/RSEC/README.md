# M$^2$VEC

This repo contains the source code for the following paper:\
[**Robust Spectral Ensemble Clustering**](https://dl.acm.org/doi/10.1145/2983323.2983745)
<br>
CIKM '16: Proceedings of the 25th ACM International on Conference on Information and Knowledge Management
<br>

## Demo
Run `demo_RSEC.m` to obtain the results of RSEC on the *iris* and *tr12* datasets.

## Generate BPs
To run RSEC on new datasets, you need to generate basic partitions in advance. Please refer to the paper for more details. 

## Citation
If you find this code useful for your research, please kindly cite our papers as follows.

```bibtex
@inproceedings{TaoCIKM16,
 author = {Tao, Zhiqiang and Liu, Hongfu and Li, Sheng and Fu, Yun},
 title = {Robust Spectral Ensemble Clustering},
 booktitle = {Proceedings of the 25th ACM International on Conference on Information and Knowledge Management},
 pages = {367--376},
 numpages = {10},
 year = {2016}
}
```

```bibtex
@article{TaoTKDD19,
  author    = {Zhiqiang Tao and
               Hongfu Liu and
               Sheng Li and
               Zhengming Ding and
               Yun Fu},
  title     = {Robust Spectral Ensemble Clustering via Rank Minimization},
  journal   = {{ACM} Transactions on Knowledge Discovery from Data},
  volume    = {13},
  number    = {1},
  pages     = {4:1--4:25},
  year      = {2019}
}
```

## Contact
Please feel free to contact <ztao@scu.edu> if you have any questions.
