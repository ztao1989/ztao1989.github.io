addpath('./utils');

%% Parameter Settings

% load datasets and pre-given basic partitions (IDX)
datafile = 'iris'; % 'tr12'
[data, gnd, K, IDX] = myLoad(datafile);

r = 100; % #BPs
times = 10; % run times for random initialization

% default: lambda2 = 0.01, lambda1 = 0.1;
% you may tune lambda2 for a better performance
lambda2 = 0.01; 
lambda1 = 0.1;
% admm solver parameters 
% you may tune rho, mu, tol to accelerate the coverage, 
% e.g, rho = 1.2, mu =1e-3, tol = 1e-4; or just use the defaul settiing in
% the function robustSEC.
opts.rho = 1.1;
opts.mu = 1e-6;
opts.tol = 1e-7;
%% generate S
result = getBinaryMatrix(IDX);
S = result*result';
S = S ./ r;
%% Robust SEC_LRR
[Z, H, E] = robustSEC(S, S, K, lambda2, lambda1, opts);
acc = zeros(1, times);
nmi = zeros(1, times);
for i = 1:times
ind = runSpectral(Z, K, 1);
[ACC1, NMI1] = exMeasure(ind, gnd);
ind = kmeans(H,K,'replicates',10);
[ACC2, NMI2] = exMeasure(ind, gnd);
acc(i) = max(ACC1, ACC2);
nmi(i) = max(NMI1, NMI2);
end
fprintf('acc: %.4f, nmi: %.4f\n', mean(acc), mean(nmi) );