function [Acc, NMI] = exMeasure(cluster, true_label)

[ cmatrix,labelnum,ncluster] = ConMatrixHard(cluster,true_label);

n = sum(sum(cmatrix));
pi = sum(cmatrix,2)/n;
pj = sum(cmatrix,1)/n;

%Normalized mutual information
NMI = cal_NMI(cmatrix,labelnum,ncluster,n,pi,pj);

new_cluster = bestMap(true_label,cluster);

Acc = mean(true_label==new_cluster);

end

function [ cmatrix,labelnum,ncluster] = ConMatrixHard(cluster,true_label)
%Obtain Contingency Matrix
[label,~,tagclu]= unique(cluster);
ncluster = size(label,1);

[tagcla,labelnum] = LableConvert( true_label );
cmatrix = zeros(ncluster,labelnum);

for i = 1: labelnum 
    claidx = tagcla==i;
    index = claidx .* tagclu;
    cmatrix(:,i) = histc(index,unique(tagclu));
end

end

function [tag,labelnum] = LableConvert(true_label)
%Obatain Class labels

%rclass = importdata(true_label);
[label,~,tag]= unique(true_label);
labelnum = size(label,1);

end

function NMI = cal_NMI(cmatrix,labelnum,ncluster,n,pi,pj)
    
    fenzi = 0;
     for i = 1 : ncluster
        for j = 1 : labelnum
           if cmatrix(i,j)>0
               fenzi = fenzi + (cmatrix(i,j)/n)*log2((cmatrix(i,j)/n)/pi(i)/pj(j));
           end
        end
     end
     
     fenmu = sqrt(sum(pi.*log2(pi))*sum(pj.*log2(pj)));
     
     NMI = fenzi/fenmu;
end

function [newL2] = bestMap(L1,L2)
%bestmap: permute labels of L2 to match L1 as good as possible
%   [newL2] = bestMap(L1,L2);
%
%   version 2.0 --May/2007
%   version 1.0 --November/2003
%
%   Written by Deng Cai (dengcai AT gmail.com)
%===========    

L1 = L1(:);
L2 = L2(:);
if size(L1) ~= size(L2)
    error('size(L1) must == size(L2)');
end

Label1 = unique(L1);
nClass1 = length(Label1);
Label2 = unique(L2);
nClass2 = length(Label2);

nClass = max(nClass1,nClass2);
G = zeros(nClass);
for i=1:nClass1
	for j=1:nClass2
		G(i,j) = length(find(L1 == Label1(i) & L2 == Label2(j)));
	end
end

[c,~] = hungarian(-G);
newL2 = zeros(size(L2));
for i=1:nClass2
    newL2(L2 == Label2(i)) = Label1(c(i));
end
end