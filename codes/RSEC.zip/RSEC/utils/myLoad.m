function [data, true_label, K, IDX] = myLoad(datafile)
    if exist(['./data/' datafile '.dat'],'file'),
        data = load(strcat('./data/',strcat(datafile,'.dat'))); % load the data
    elseif exist(['./data/' datafile '.mat'],'file'),
        load(strcat('./data/',strcat(datafile,'.mat')));
        if exist('fea','var')
            data = fea;
        elseif exist('fts','var')
            data = fts;
        end;
    end;
    if exist(['./data/' datafile '_rclass.dat'],'file'),
        true_label = load(strcat('./data/',strcat(datafile,'_rclass.dat')));
    elseif exist(['./data/' datafile '.mat.rclass'],'file'),
        true_label = load(['./data/' datafile '.mat.rclass']);
    elseif exist('gnd','var')
        true_label = gnd;
    elseif exist('labels','var')
        true_label = labels;
    end;
    if min(min(true_label))==0,
        true_label = true_label+1;
    end
    if ~isequal(class(data),'double'),
        data = double(data);
    end;
    K = length(unique(true_label));
    % read IDX
    if exist(['./IDX/' datafile '-RPS-IDX.mat'],'file'),
        disp('RPS strategy is employed')
        idx_load = load(['./IDX/' datafile '-RPS-IDX.mat']);
        IDX = idx_load.IDX;
    else
        r = 100;
        dist_of_basic_cluster = 'cosine'; % (sqeuclidean, cosine)
        randKi = 1; % 0: Ki=K, 1: Ki=random, Vector: Ki=randKi, for BasicCluster_RPS only
        disp('Generating the BPs now');
        IDX = BasicCluster_RPS(data, r, K, dist_of_basic_cluster, randKi);
        save(['./IDX/' datafile '-RPS-IDX'], 'IDX');
    end;
end
