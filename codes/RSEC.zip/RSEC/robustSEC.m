function [Z, H, E] = robustSEC(X, A, K, lambda2, lambda1, opts)
% This code was adpated from the LRR work released by 
% "Robust Recovery of Subspace Structures by Low-Rank Representation", TPAMI, 2013.
% This function implements the RSEC algorithm of the following paper:
% "Robust Spectral Ensemble  Clustering", CIKM, 2016
%
% We use inexact ALM solve the following optimization problem
% tr(H^TLH) + lambda_1*|Z|_* + lambda_2*|E|_{2,1} + 
% s.t., S = SZ+E, H^T*H = I, and L = I - D^{-1/2}((Z+Z^T)/2+HH^T)D^{-1/2}
% inputs:
%       X and A are both co-association matrix S
% outputs:
%       Z: LRR codes, H: fianl consensus partition, E: sparse residual
%       matrix

%% para settings
display = true;
[d, n] = size(X);
m = size(A,2);
max_mu = 1e10;

if isfield(opts, 'mu')
    mu=opts.mu;
else
    mu = 1.5 / norm(X, 2);
end
if isfield(opts, 'rho')
    rho=opts.rho;
else
    rho=1.2;
end
if isfield(opts, 'maxIter')
    maxIter=opts.maxIter;
else
    maxIter=200;
end
if isfield(opts,'tol')
    tol=opts.tol;
else
    tol = 1e-7;   
end


atx = A'*X;
inv_a = eye(m)/( eye(m) + A'*A);

%% Initializing optimization variables
Z = zeros(m,n);
E = sparse(d,n);
H = zeros(n,K);
D = zeros(n,n);
Y1 = zeros(d,n);
Y2 = zeros(m,n);

%% Start main loop
iter = 0;
if display
    disp(['initial,rank=' num2str(rank(Z))]);
end

while iter<maxIter
    iter = iter + 1;
    %update J
    temp = Z + Y2/mu;
    [U,S,V] = svd(temp,'econ');
    S = diag(S);
    svp = length(find(S>lambda1/mu));
    if svp>=1
        S = S(1:svp)-lambda1/mu;
    else
        svp = 1;
        S = 0;
    end
    J = U(:,1:svp)*diag(S)*V(:,1:svp)';
    
    %udpate Z
    tempL =  (D*(H*H')*D);
    Z = inv_a*(atx-A'*E+J + (A'*Y1- Y2 + tempL )/mu);
    
    %update E
    xmaz = X-A*Z;
    temp = xmaz+Y1/mu;
    E = solve_l1l2(temp,lambda2/mu);

    % update H 
    L = (Z+Z')/2 + (H*H');
    [H, D] = calH(L,K);
    
    % stop criterion 
    leq1 = xmaz-E;
    leq2 = Z-J;
    stopC = max(max(max(abs(leq1))),max(max(abs(leq2))));
    
    if display && (iter==1 || mod(iter,50)==0 || stopC<tol)
        disp(['iter ' num2str(iter) ',mu=' num2str(mu,'%2.1e') ...
             ',rank=' num2str(rank(Z,1e-3*norm(Z,2))) ',stopALM=' num2str(stopC,'%2.3e')]);   
    end
    if stopC<tol 
        break;
    else
        Y1 = Y1 + mu*leq1;
        Y2 = Y2 + mu*leq2;
        mu = min(max_mu,mu*rho);
    end
end

end

function [H, D] = calH(L,K)
    % preprocessing
    [U,S,~] = svd(L,'econ');
    S = diag(S);
    r = sum(S>1e-4*S(1));
    U = U(:,1:r);S = S(1:r);
    U = U*diag(sqrt(S));
    U = normr(U);
    L = (U*U').^4;

    % spectral clustering
    D = diag(1./sqrt(sum(L,2)));
    L = D*L*D;
    [U, ~, ~] = svd(L);
    V = U(:,1:K);
    H = D*V;
end

function [E] = solve_l1l2(W,lambda)
    n = size(W,2);
    E = W;
    for i=1:n
        E(:,i) = solve_l2(W(:,i),lambda);
    end
end
function [x] = solve_l2(w,lambda)
    % min lambda |x|_2 + |x-w|_2^2
    nw = norm(w);
    if nw>lambda
        x = (nw-lambda)*w/nw;
    else
        x = zeros(length(w),1);
    end
end

