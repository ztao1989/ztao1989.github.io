# M$^2$VEC

This repo contains the source code for the following paper:\
[**Marginalized Multiview Ensemble Clustering**](https://ieeexplore.ieee.org/document/8691702)
<br>
IEEE Transactions on Neural Networks and Learning Systems, vol. 31, no. 2, pp. 600-611, 2020.
<br>

## Demo
Run `demo_M2VEC.m` to obtain the results of M$^2$VEC on the *3sources* and *bbcsport* datasets.

## Generate multi-view BPs
To run M$^2$VEC on new datasets, you need to generate multi-view basic partitions in 
advance. Please refer to `genBPs.m` for more details. 

## Citation
If you find this code useful for your research, please kindly cite our papers as follows.

```bibtex
@inproceedings{TaoLLDF17,
  author    = {Zhiqiang Tao and Hongfu Liu and Sheng Li and Zhengming Ding and Yun Fu},
  title     = {From Ensemble Clustering to Multi-View Clustering},
  booktitle = {IJCAI},
  pages     = {2843--2849},
  year      = {2017}
}
```

```bibtex
@article{TaoTNNLS20,
  author    = {Zhiqiang Tao and
               Hongfu Liu and
               Sheng Li and
               Zhengming Ding and
               Yun Fu},
  title     = {Marginalized Multiview Ensemble Clustering},
  journal   = {{IEEE} Transactions on Neural Networks and Learning Systems},
  volume    = {31},
  number    = {2},
  pages     = {600--611},
  year      = {2020}
}
```

## Contact
Please feel free to contact <ztao@scu.edu> if you have any questions.
