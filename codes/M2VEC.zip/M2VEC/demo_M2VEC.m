clear;
addpath('./utils');
datafiles = {'3sources', 'bbcsport'};

lambda1 = 1;
lambda2 = 0.01;
lambda3 = 1;

opts.mu=1e-3;
opts.rho=1.2; %increase rho to accelerate the convergence 
opts.tol=1e-4; 
opts.maxIter=400;
opts.noise = 0.1;

%% main loop
for Did = 1:numel(datafiles)

    dataset=['./datasets/' datafiles{Did} '.mat'];    
    disp([datafiles{Did} ' is running...'])
    tmp = load(dataset);
    S  = tmp.S;
    M = tmp.M;
    K  = tmp.K;
    gnd = tmp.gnd;
    layers = 2;
    %% M2VEC
    hS = S;
    tic; t_old = 0;
    for i=1:layers   
        % Update Z and W
        [Z, H, E, W] = mec_simW(hS, K, lambda1, lambda2, lambda3, opts);
        t = toc;
        reu = comstd(gnd, K, Z, H, 5);
        fprintf('%d-layer mec, acc=%.5f, rn=%.5f, nmi=%.5f with time %.5f\n', ...
            i, reu.acc(1), reu.rn(1), reu.nmi(1), t-t_old);
        runtime = t-t_old;
        t_old = t;
        % Update hidden S for next layer 
        for v=1:M
            WS = tanh(W{v}*hS{v});
            hS{v} = (WS + WS')/2;
        end
    end
end