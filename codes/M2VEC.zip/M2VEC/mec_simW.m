function [Z, H, E, W] = mec_simW(A, K, lambda1, lambda2, lambda3, opts)
% min tr(H^TLH) + lmabda_1 ||J||_{*} + \lambda_2 \sum_{v=1}^{m}||E^{(v)}||_1 + lambda_3 \Omega(W) 
% s.t. W^{(v)}S^{(v)}+HH^T = W^{(v)}S^{(v)}Z + E^{(v)}, Z = J, Z>=0, Z*1 = 1
% \Omega(W) = 1/2 \Sigma_v tr[(\bar{S}^{(v)}-W^{(v)}\tilde{S}^{(v)})^T(\bar{S}^{(v)}-W^{(v)}\tilde{S}^{(v)})]

%% Parameter setting
M = length(A);
n = size(A{1},1);
R = cell(M,1); %S^{v}-S{v}Z
etas = zeros(1,M);

display = true;
max_mu = 1e10;

if isfield(opts,'rho')
    rho=opts.rho;
else
    rho=1.2;
end
if isfield(opts,'maxIter')
    maxIter=opts.maxIter;
else
    maxIter=200;
end
if isfield(opts,'tol')
    tol=opts.tol;
else
    tol = 1e-6;   
end
if isfield(opts,'mu')
    mu=opts.mu;
else
    mu = n*tol;   
end
if isfield(opts,'noise')
    noise=opts.noise;
else
    noise = 0.1;
end

%% Initializing optimization variables
Z = zeros(n,n);
H = zeros(n,K);
Lambda = zeros(n,n);
u = zeros(n,1);

W = cell(1,M);
for v=1:M
    [~,W{v}] = mDA(A{v}, noise, 1e-5);
end

I = ones(n,1);
Y = cell(1,M);
E = cell(1,M);
P = cell(1,M);
Q = cell(1,M);
reg = 1e-5 * eye(n);

q = ones(n, 1)*(1-noise);
for v=1:M
   Y{v} = zeros(n,n);
   E{v} = sparse(n,n);
   xxt = A{v}*A{v}';
   Q{v} = xxt .* (q*q');
   Q{v}(1:n+1:end) = q .* diag(xxt);
   P{v} = xxt .* repmat(q', n, 1);
end
%% Start main loop
iter = 0;
if display
    disp(['initial,rank=' num2str(rank(Z))]);
end
while iter<maxIter
    iter = iter + 1;
    
    % Update J
    temp = Z + Lambda/mu;
    [U,S,V] = svd(temp,'econ');
    S = diag(S);
    svp = length(find(S>lambda1/mu));
    if svp>=1
        S = S(1:svp)-lambda1/mu;
    else
        svp = 1;
        S = 0;
    end
    J = U(:,1:svp)*diag(S)*V(:,1:svp)';
    
    % Updata eta and R^(v)
    for v=1:M
        etas(v) = norm(W{v}*A{v}, 2);
        R{v} = A{v} - A{v}*Z;
    end
    eta = sum(etas.^2);
    eta = eta + n + 1;
    
    % Udpate Z
    tmp = repmat(H, 1, 1, n);
    ptmp = permute(tmp, [3 2 1]);
    G = sum((ptmp - tmp).^2, 2);
    G = reshape(G, [n n]);
    eta = eta + norm(G,2)^2;
    
    HHt = H*H';
    
    tempA = 0;
    for v=1:M
        tmp = -A{v}'*(W{v}'*W{v})*R{v} + A{v}'*W{v}'*(-HHt+E{v}-Y{v}/mu);
        tempA = tempA + tmp;
    end  
    alpha = Z*I - I + u/mu;
    C = 0.5*G/mu + (Z - J + Lambda/mu) + tempA + alpha*I';
    Z = Z - C/eta;
    Z(Z<0) = 0;
    
    % Update E
    leq1 = zeros(1,M);
    for v=1:M
      xmaz = W{v}*R{v} + HHt;
      temp = xmaz+Y{v}/mu;
      E{v} = max(0, temp - lambda2/mu)+min(0, temp + lambda2/mu);
      % Updates Lagrange Multipliers
      Y{v} = Y{v} + mu*(xmaz-E{v});
      leq1(v) = max(max(abs(xmaz-E{v}))); % stop for max S-SZ-E
    end
    
    % Update W 
    for v = 1:M
        P_hat = lambda3 * P{v} - (Y{v}+mu*(HHt-E{v}))*R{v}'; 
        Q_hat = lambda3 * Q{v} + mu*(R{v}*R{v}');
        W{v} = P_hat/(Q_hat + reg);
    end

    % Update H 
    L = (Z+Z')/2;
    [H, ~] = calH(L,K);
    
    % stop criterion 
    leq2 = Z-J;
    leq3 = Z*I - I;
    stopC = max( [max(leq1), max(max(abs(leq2))), max(abs(leq3)) ]);
    
    if display && (iter==1 || mod(iter,50)==0 || stopC<tol)
        disp(['iter ' num2str(iter) ',mu=' num2str(mu,'%2.1e') ...
             ',rank=' num2str(rank(Z,1e-3*norm(Z,2))) ',stopALM=' num2str(stopC,'%2.3e')]);   
    end
    if stopC<tol 
        break;
    else
        Lambda = Lambda + mu*leq2;
        u = u + mu*leq3;
        mu = min(max_mu,mu*rho);
    end
end

end

function [H, D] = calH(L,K)
    % preprocessing
    [U,S,~] = svd(L,'econ');
    S = diag(S);
    r = sum(S>1e-4*S(1));
    U = U(:,1:r);S = S(1:r);
    U = U*diag(sqrt(S));
    U = normr(U);
    L = (U*U').^4;
    % spectral clustering
    D = diag(1./sqrt(sum(L,2)));
    L = D*L*D;
    [U, ~, ~] = svd(L);
    V = U(:,1:K);
    H = D*V;
end

function [hx, W] = mDA(xx,noise,lambda)
    [d, ~] = size(xx);
    % scatter matrix S
    S = xx*xx';
    % corruption vector
    q = ones(d, 1)*(1-noise);

    % Q: (d+1)x(d+1)
    Q = S.*(q*q');
    Q(1:d+1:end) = q.*diag(S);
    P = S .* repmat(q', d, 1);
    % final W = P*Q^-1, dx(d+1);
    reg = lambda*eye(d);
    W = P/(Q+reg);
    hx = W*xx;
    hx = tanh(hx);
end