addpath('./utils');
datapath = './data/';
savepath = './datasets/';
datafile = '';

sign = 1; % select 1 for RPS-IDX; select 2 for RFS-IDX
r = 100; % number of basic partitionings
dist_of_basic_cluster = 'cosine'; % (sqeuclidean, cosine)
BasicClusterer = 1; % 1-BasicCluster_RPS, 2-BasicCluster_RFS
randKi = 1; % 0: Ki=K, 1: Ki=random, Vector: Ki=randKi, for BasicCluster_RPS only

xx = load([datapath datafile '.mat']);
data = xx.data;
if isfield(xx, 'truth')
    gnd = xx.truth;
else
    gnd = xx.gnd;
end

if min(gnd)==0
    gnd = gnd + 1;
end
K = length(unique(gnd));
M = length(data);
IDXs = cell(1,M);
S = cell(1,M);
for i=1:M
    if BasicClusterer==1
        IDX = BasicCluster_RPS(data{i},r,K,dist_of_basic_cluster,randKi);
    elseif BasicClusterer==2
        [~,d] = size(data{i});
        nFeature = 0.2;
        IDX = BasicCluster_RFS2(data{i},r,K,dist_of_basic_cluster,nFeature);
    end
    IDXs{i} = IDX;
    result = getBinaryMatrix(IDX);
    tmp = result*result';
    tmp = tmp ./ r;
    S{i} = tmp;
end
save([savepath datafile '.mat'], 'data', 'gnd', 'K', 'M', 'IDXs', 'S', '-v7.3');

