clear; clc;
addpath('./utils');
datafile = '3sources'; %or bbcsport 

%%
dataset=['./datasets/' datafile '.mat'];
savepath = ['./mecReus/' datafile '.mat'];
tmp = load(dataset);
disp([datafile ' is running...']);
S  = tmp.S; %co-association matrices among multiple views
M = tmp.M;
K  = tmp.K;
gnd = tmp.gnd;

%% MEC
fprintf('======================================\n');
fprintf('running mec\n');

lambda1 = 1;
lambda2 = 0.01;

opts.mu=1e-3;
opts.rho=1.1;
opts.tol=1e-4; 
opts.maxIter=200;
tic;
[Z, H, E] = mec_simH(S, K, lambda1, lambda2, opts);
reu = comstd(gnd, K, Z, H);
fprintf('nmi: %.4f, rn: %.4f\n', reu.nmi(1), reu.rn(1));
toc;