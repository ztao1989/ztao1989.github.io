function [Z, H, E] = mec_simH(S, K, lambda1, lambda2, opts)
%% Parameter setting
M = length(S);
n = size(S{1},1);
A = zeros(n,n,M);
ata = zeros(n,n,M);
etas = zeros(1,M);
for v=1:M
    A(:,:,v) = S{v};
    etas(v) = norm(S{v},2);
    ata(:,:,v) = S{v}'*S{v};% Sv^T*Sv
end
eta = sum(etas.^2);
eta = eta + n + 1;

atx = sum(ata,3); % sum(SvT*Sv)

display = true;
max_mu = 1e10;

if isfield(opts,'rho')
    rho=opts.rho;
else
    rho=1.2;
end
if isfield(opts,'maxIter')
    maxIter=opts.maxIter;
else
    maxIter=200;
end
if isfield(opts,'tol')
    tol=opts.tol;
else
    tol = 1e-6;   
end
if isfield(opts,'mu')
    mu=opts.mu;
else
    mu = n*tol;   
end

%% Initializing optimization variables
Z = zeros(n,n);
H = zeros(n,K);
%P = zeros(n,n);
Lambda = zeros(n,n);
W = zeros(n,1);
I = ones(n,1);
Y = cell(1,M);
E = cell(1,M);
for i=1:M
   Y{i} = zeros(n,n);
   E{i} = sparse(n,n);
end
%record = zeros(3,maxIter);

%% Start main loop
iter = 0;
if display
    disp(['initial,rank=' num2str(rank(Z))]);
end
while iter<maxIter
    iter = iter + 1;
    %update J
    temp = Z + Lambda/mu;
    [U,S,V] = svd(temp,'econ');
    S = diag(S);
    svp = length(find(S>lambda1/mu));
    if svp>=1
        S = S(1:svp)-lambda1/mu;
    else
        svp = 1;
        S = 0;
    end
    J = U(:,1:svp)*diag(S)*V(:,1:svp)';
    
    %udpate Z
    % compute P by H first
%     for i=1:n
%         tmp = repmat(H(i,:), n, 1) - H;
%         P(:,i) = sum(tmp.^2, 2);
%     end
    tmp = repmat(H, 1, 1, n);
    ptmp = permute(tmp, [3 2 1]);
    P = sum((ptmp - tmp).^2, 2);
    P = reshape(P, [n n]);
    eta = eta + norm(P,2)^2;
    temp = zeros(n,n,M);
    for v=1:M
        temp(:,:,v) = A(:,:,v)' * (E{v}-Y{v}/mu);
    end  
    temp = sum(temp,3);%sum(Sv'(Ev-Yv/mu))
    tmpH = H*H';
    temp = temp - sum(A,3)*tmpH;
    alpha = Z*I - I + W/mu;
    C = 0.5*P/mu + Z - J + Lambda/mu + atx*Z + temp - atx + alpha*I';
    Z = Z - C/eta;
    Z(Z<0) = 0;%non-negative project
    
    %update E
    leq1 = zeros(1,M);
    for i=1:M
      xmaz = A(:,:,i)-A(:,:,i)*Z + tmpH;
      temp = xmaz+Y{i}/mu;
      E{i} = max(0, temp - lambda2/mu)+min(0, temp + lambda2/mu);
      % Updates Lagrange Multipliers
      Y{i} = Y{i} + mu*(xmaz-E{i});
      leq1(i) = max(max(abs(xmaz-E{i}))); % stop for max S-SZ-E
    end

    % update H 
    L = (Z+Z')/2;
    [H, ~] = calH(L,K);
    
    % stop criterion 
    leq2 = Z-J;
    leq3 = Z*I - I;
    stopC = max( [max(leq1), max(max(abs(leq2))), max(abs(leq3)) ]);
    
    if display && (iter==1 || mod(iter,50)==0 || stopC<tol)
        disp(['iter ' num2str(iter) ',mu=' num2str(mu,'%2.1e') ...
             ',rank=' num2str(rank(Z,1e-3*norm(Z,2))) ',stopALM=' num2str(stopC,'%2.3e')]);   
    end
    if stopC<tol 
        break;
    else
        Lambda = Lambda + mu*leq2;
        W = W + mu*leq3;
        mu = min(max_mu,mu*rho);
    end
end

end

function [H, D] = calH(L,K)
    % preprocessing
    [U,S,~] = svd(L,'econ');
    S = diag(S);
    r = sum(S>1e-4*S(1));
    U = U(:,1:r);S = S(1:r);
    U = U*diag(sqrt(S));
    U = normr(U);
    L = (U*U').^4;
    % spectral clustering
    D = diag(1./sqrt(sum(L,2)));
    L = D*L*D;
    [U, ~, ~] = svd(L);
    V = U(:,1:K);
    H = D*V;
end
